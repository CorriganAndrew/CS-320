package com.appointment;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import java.util.Calendar;
import java.util.Date;

class AppointmentServiceTest {

    private AppointmentService service;
    private Date futureDate;

    // Runs before each test method to set up a fresh AppointmentService
    @BeforeEach
    void setUp() {
        service = new AppointmentService();
        // Set up a valid future date (tomorrow)
        Calendar cal = Calendar.getInstance();
        cal.add(Calendar.DAY_OF_MONTH, 1);
        futureDate = cal.getTime();
    }

    // Test adding an appointment and then retrieving it
    @Test
    void testAddAndRetrieveAppointment() {
        // Add an appointment with a valid ID and description
        service.addAppointment("Apt001", futureDate, "Test Appointment");
        
        // Retrieve the appointment and verify its values
        Appointment apt = service.getAppointment("Apt001");
        assertNotNull(apt, "The appointment should not be null after adding");
        assertEquals("Apt001", apt.getAppointmentId());
        assertEquals(futureDate, apt.getAppointmentDate());
        assertEquals("Test Appointment", apt.getDescription());
    }
    
    // Test that adding an appointment with a duplicate ID throws an exception
    @Test
    void testAddDuplicateAppointmentThrowsException() {
        service.addAppointment("Apt001", futureDate, "Test Appointment");
        
        Exception exception = assertThrows(IllegalArgumentException.class, () -> {
            service.addAppointment("Apt001", futureDate, "Duplicate Appointment");
        });
        
        assertEquals("Appointment ID already exists", exception.getMessage());
    }

    // Test updating the appointment's description
    @Test
    void testUpdateAppointmentDescription() {
        service.addAppointment("Apt002", futureDate, "Initial Description");
        service.updateAppointmentDescription("Apt002", "Updated Description");
        
        Appointment apt = service.getAppointment("Apt002");
        assertEquals("Updated Description", apt.getDescription());
    }

    // Test updating the appointment's date
    @Test
    void testUpdateAppointmentDate() {
        service.addAppointment("Apt003", futureDate, "Initial Appointment");
        
        // Prepare a new valid future date (two days from now)
        Calendar cal = Calendar.getInstance();
        cal.add(Calendar.DAY_OF_MONTH, 2);
        Date newDate = cal.getTime();
        service.updateAppointmentDate("Apt003", newDate);
        
        Appointment apt = service.getAppointment("Apt003");
        assertEquals(newDate, apt.getAppointmentDate());
    }

    // Test deleting an appointment
    @Test
    void testDeleteAppointment() {
        service.addAppointment("Apt004", futureDate, "To be deleted");
        service.deleteAppointment("Apt004");
        
        Exception exception = assertThrows(IllegalArgumentException.class, () -> {
            service.getAppointment("Apt004");
        });
        
        assertEquals("Appointment not found", exception.getMessage());
    }
    
    // Verify that trying to add an appointment with a past date throws an exception
    @Test
    void testSetAppointmentWithPastDateThrowsException() {
        // Create a past date (yesterday)
        Calendar cal = Calendar.getInstance();
        cal.add(Calendar.DAY_OF_MONTH, -1);
        Date pastDate = cal.getTime();
        
        Exception exception = assertThrows(IllegalArgumentException.class, () -> {
            service.addAppointment("Apt005", pastDate, "Past Appointment");
        });
        assertEquals("Appointment date cannot be in the past", exception.getMessage());
    }
    
    // Verify that an appointment with an ID longer than 10 characters is rejected
    @Test
    void testSetInvalidAppointmentId() {
        Exception exception = assertThrows(IllegalArgumentException.class, () -> {
            service.addAppointment("Apt1234567890", futureDate, "Invalid ID Appointment");
        });
        assertEquals("Invalid Appointment ID", exception.getMessage());
    }
    
    // Verify that an appointment with a description longer than 50 characters is rejected
    @Test
    void testSetInvalidDescription() {
        String longDescription = "This is a very long description that is definitely more than fifty characters long.";
        Exception exception = assertThrows(IllegalArgumentException.class, () -> {
            service.addAppointment("Apt006", futureDate, longDescription);
        });
        assertEquals("Invalid description (cannot exceed 50 characters)", exception.getMessage());
    }
}
