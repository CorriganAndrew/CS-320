package com.appointment;

import static org.junit.jupiter.api.Assertions.*;

import java.util.Calendar;
import java.util.Date;

import org.junit.jupiter.api.Test;

class AppointmentTest {

    // Helper method to create a future date (tomorrow)
    private Date getFutureDate() {
        Calendar cal = Calendar.getInstance();
        cal.add(Calendar.DAY_OF_MONTH, 1);
        return cal.getTime();
    }

    // Test that a valid Appointment object is created successfully
    @Test
    void testValidAppointmentCreation() {
        Date futureDate = getFutureDate();
        Appointment apt = new Appointment("ValidID", futureDate, "A valid description");
        assertEquals("ValidID", apt.getAppointmentId());
        assertEquals(futureDate, apt.getAppointmentDate());
        assertEquals("A valid description", apt.getDescription());
    }

    // Test that an appointment with an ID longer than 10 characters throws an exception
    @Test
    void testAppointmentIdTooLong() {
        Date futureDate = getFutureDate();
        Exception exception = assertThrows(IllegalArgumentException.class, () -> {
            new Appointment("TooLongID123", futureDate, "A valid description");
        });
        assertEquals("Invalid Appointment ID", exception.getMessage());
    }

    // Test that an appointment with a description longer than 50 characters throws an exception
    @Test
    void testDescriptionTooLong() {
        Date futureDate = getFutureDate();
        String longDescription = "This description is definitely longer than fifty characters and should fail.";
        Exception exception = assertThrows(IllegalArgumentException.class, () -> {
            new Appointment("ValidID", futureDate, longDescription);
        });
        assertEquals("Invalid description (cannot exceed 50 characters)", exception.getMessage());
    }

    // Test that an appointment with a past date throws an exception
    @Test
    void testPastDateAppointment() {
        // Create a past date (yesterday)
        Calendar cal = Calendar.getInstance();
        cal.add(Calendar.DAY_OF_MONTH, -1);
        Date pastDate = cal.getTime();
        
        Exception exception = assertThrows(IllegalArgumentException.class, () -> {
            new Appointment("ValidID", pastDate, "A valid description");
        });
        assertEquals("Appointment date cannot be in the past", exception.getMessage());
    }
}

