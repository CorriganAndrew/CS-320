package com.appointment;

import java.util.Date;

public class Appointment {
    
    private String appointmentId;
    private Date appointmentDate;
    private String description;
    
    // Constructor
    public Appointment(String appointmentId, Date appointmentDate, String description) {
        // Validate and set fields
        setAppointmentId(appointmentId);
        setAppointmentDate(appointmentDate);
        setDescription(description);
    }

    // Appointment ID: no longer than 10 characters
    public void setAppointmentId(String appointmentId) {
        if (appointmentId == null || appointmentId.length() > 10) {
            throw new IllegalArgumentException("Invalid Appointment ID");
        }
        this.appointmentId = appointmentId;
    }

    // Appointment Date: cannot be null or in the past
    public void setAppointmentDate(Date appointmentDate) {
        if (appointmentDate == null) {
            throw new IllegalArgumentException("Appointment date cannot be null");
        }
        // Check that date is not in the past
        Date now = new Date();
        if (appointmentDate.before(now)) {
            throw new IllegalArgumentException("Appointment date cannot be in the past");
        }
        this.appointmentDate = appointmentDate;
    }

    // Description: no more than 50 characters
    public void setDescription(String description) {
        if (description == null || description.length() > 50) {
            throw new IllegalArgumentException("Invalid description (cannot exceed 50 characters)");
        }
        this.description = description;
    }

    // Getters for each field
    public String getAppointmentId() {
        return appointmentId;
    }

    public Date getAppointmentDate() {
        return appointmentDate;
    }

    public String getDescription() {
        return description;
    }
}

