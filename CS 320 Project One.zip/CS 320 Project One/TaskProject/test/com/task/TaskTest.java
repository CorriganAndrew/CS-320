package com.task;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

/**
 * Tests the rules for Task objects:
 *   - taskId: must be final, not null, and <= 10 chars
 *   - name: not null, <= 20 chars
 *   - description: not null, <= 50 chars
 */
public class TaskTest {

    @Test
    void testValidTaskCreation() {
        Task task = new Task("12345", "Short Name", "Brief description");
        assertEquals("12345", task.getTaskId());
        assertEquals("Short Name", task.getName());
        assertEquals("Brief description", task.getDescription());
    }

    @Test
    void testInvalidTaskId_Null() {
        assertThrows(IllegalArgumentException.class, () -> {
            new Task(null, "Name", "Description");
        });
    }

    @Test
    void testInvalidTaskId_TooLong() {
        // 11 characters is too much
        assertThrows(IllegalArgumentException.class, () -> {
            new Task("12345678901", "Name", "Description");
        });
    }

    @Test
    void testInvalidName_Null() {
        assertThrows(IllegalArgumentException.class, () -> {
            new Task("1", null, "Some desc");
        });
    }

    @Test
    void testInvalidName_TooLong() {
        // 21 characters (1 over the limit)
        String tooLong = "ABCDEFGHIJKLMNOPQRSTU";
        assertEquals(21, tooLong.length());
        assertThrows(IllegalArgumentException.class, () -> {
            new Task("2", tooLong, "Description");
        });
    }

    @Test
    void testInvalidDescription_Null() {
        assertThrows(IllegalArgumentException.class, () -> {
            new Task("3", "Name", null);
        });
    }

    @Test
    void testInvalidDescription_TooLong() {
        // 51 characters (just over the limit)
        String tooLongDesc = "ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789ABCDEFGHIJKLMNO";
        assertEquals(51, tooLongDesc.length());
        assertThrows(IllegalArgumentException.class, () -> {
            new Task("3", "Name", tooLongDesc);
        });
    }

    @Test
    void testSetNameValid() {
        Task task = new Task("123", "OldName", "OldDescription");
        task.setName("NewName");
        assertEquals("NewName", task.getName());
    }

    @Test
    void testSetDescriptionValid() {
        Task task = new Task("456", "OldName", "OldDescription");
        task.setDescription("NewDescription");
        assertEquals("NewDescription", task.getDescription());
    }
}

