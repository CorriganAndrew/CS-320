package com.task;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

/**
 * Tests TaskService behavior:
 *   - addTask ensures IDs are unique
 *   - deleteTask removes tasks
 *   - updateTask changes name/description
 *   - getTask fetches by ID
 */
public class TaskServiceTest {

    private TaskService service;

    @BeforeEach
    void setUp() {
        service = new TaskService();
    }

    @Test
    void testAddTaskAndRetrieve() {
        Task t = new Task("111", "Alpha", "First Task");
        service.addTask(t);
        Task retrieved = service.getTask("111");
        assertNotNull(retrieved);
        assertEquals("Alpha", retrieved.getName());
    }

    @Test
    void testAddDuplicateId() {
        Task t1 = new Task("222", "Task1", "Description1");
        Task t2 = new Task("222", "Task2", "Description2");

        service.addTask(t1);
        // Should fail since taskId must be unique
        assertThrows(IllegalArgumentException.class, () -> service.addTask(t2));
    }

    @Test
    void testDeleteTask() {
        Task t = new Task("333", "ToDelete", "Will be deleted");
        service.addTask(t);
        assertNotNull(service.getTask("333"));

        service.deleteTask("333");
        assertNull(service.getTask("333"));
    }

    @Test
    void testUpdateTask() {
        Task t = new Task("444", "Original Name", "Original Desc");
        service.addTask(t);

        service.updateTask("444", "Updated Name", "Updated Desc");

        Task updated = service.getTask("444");
        assertEquals("Updated Name", updated.getName());
        assertEquals("Updated Desc", updated.getDescription());
    }

    @Test
    void testUpdateNonExistentTask() {
        // No task with ID "999", should throw
        assertThrows(IllegalArgumentException.class, () -> {
            service.updateTask("999", "NewName", "NewDesc");
        });
    }
}

