package com.task;

import java.util.HashMap;
import java.util.Map;

/**
 * Handles storing and managing Task objects in memory.
 * You can:
 *   - add a task (but IDs must be unique)
 *   - delete a task by ID
 *   - update a task's name and description
 *   - look up a task by ID
 */
public class TaskService {

    private Map<String, Task> tasks = new HashMap<>();

    /**
     * Adds a new Task. If the taskId already exists, throws an error.
     */
    public void addTask(Task task) {
        if (tasks.containsKey(task.getTaskId())) {
            throw new IllegalArgumentException("Task ID already exists: " + task.getTaskId());
        }
        tasks.put(task.getTaskId(), task);
    }

    /**
     * Deletes a task based on ID. If it doesn't exist, nothing happens.
     * (You could change this to throw an error if needed.)
     */
    public void deleteTask(String taskId) {
        tasks.remove(taskId);
    }

    /**
     * Updates name and description of a task. Leaves ID alone.
     * Throws an error if taskId doesn't match anything.
     */
    public void updateTask(String taskId, String newName, String newDescription) {
        Task existing = tasks.get(taskId);
        if (existing == null) {
            throw new IllegalArgumentException("No task found with ID: " + taskId);
        }
        // Let the Task class handle validation
        existing.setName(newName);
        existing.setDescription(newDescription);
    }

    /**
     * Returns the Task for a given ID, or null if it's not found.
     */
    public Task getTask(String taskId) {
        return tasks.get(taskId);
    }
}
