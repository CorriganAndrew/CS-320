package com.task;

/**
 * Represents a task with some pretty specific rules:
 *  - taskId: must be unique, max 10 characters, not null, and can't be changed later
 *  - name: max 20 characters, not null
 *  - description: max 50 characters, not null
 */
public class Task {
    private final String taskId; // Can't be changed once it's set
    private String name;
    private String description;

    /**
     * This constructor takes care of all the rule checks when you create a new Task.
     */
    public Task(String taskId, String name, String description) {
        // Check if taskId is valid (not null, not too long)
        if (taskId == null || taskId.length() > 10) {
            throw new IllegalArgumentException("Invalid task ID (null or exceeds 10 chars)");
        }
        this.taskId = taskId;

        // Use the setters to validate and assign name and description
        setName(name);
        setDescription(description);
    }

    // --- GETTERS ---

    public String getTaskId() {
        return taskId;
    }

    public String getName() {
        return name;
    }

    public String getDescription() {
        return description;
    }

    // --- SETTERS ---
    /**
     * Updates the name of the task (if valid).
     * @param name New name, must be non-null and max 20 characters
     */
    public void setName(String name) {
        if (name == null || name.length() > 20) {
            throw new IllegalArgumentException("Invalid name (null or exceeds 20 chars)");
        }
        this.name = name;
    }

    /**
     * Updates the description of the task (if valid).
     * @param description New description, must be non-null and max 50 characters
     */
    public void setDescription(String description) {
        if (description == null || description.length() > 50) {
            throw new IllegalArgumentException("Invalid description (null or exceeds 50 chars)");
        }
        this.description = description;
    }
}
