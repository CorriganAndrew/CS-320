package com.appointment;

import java.util.HashMap;
import java.util.Date;

public class AppointmentService {
    // HashMap to store the appointments
    // Key: Appointment ID, Value: Appointment object
    private HashMap<String, Appointment> appointments;

    // Constructor
    public AppointmentService() {
        appointments = new HashMap<>();
    }

    // Create a new appointment
    public void addAppointment(String appointmentId, Date date, String description) {
        // Check if appointment with this ID already exists
        if (appointments.containsKey(appointmentId)) {
            throw new IllegalArgumentException("Appointment ID already exists");
        }
        
        // Create and add a new Appointment object
        Appointment newAppointment = new Appointment(appointmentId, date, description);
        appointments.put(appointmentId, newAppointment);
    }

    // Read an appointment by ID
    public Appointment getAppointment(String appointmentId) {
        if (!appointments.containsKey(appointmentId)) {
            throw new IllegalArgumentException("Appointment not found");
        }
        return appointments.get(appointmentId);
    }

    // Update appointment fields
    public void updateAppointmentDate(String appointmentId, Date newDate) {
        Appointment appt = getAppointment(appointmentId);
        appt.setAppointmentDate(newDate);
    }

    public void updateAppointmentDescription(String appointmentId, String newDescription) {
        Appointment appt = getAppointment(appointmentId);
        appt.setDescription(newDescription);
    }

    // Delete appointment
    public void deleteAppointment(String appointmentId) {
        if (!appointments.containsKey(appointmentId)) {
            throw new IllegalArgumentException("Appointment not found");
        }
        appointments.remove(appointmentId);
    }
}
