package com.contact;

import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.Test;

/**
 * Makes sure the Contact class actually enforces its validation rules
 * in both the constructor and the setters.
 */
public class ContactTest {

    @Test
    void testValidContact() {
        Contact c = new Contact("12345", "John", "Doe", "1234567890", "123 Some St");

        assertEquals("12345", c.getContactID());
        assertEquals("John", c.getFirstName());
        assertEquals("Doe", c.getLastName());
        assertEquals("1234567890", c.getPhoneNumber());
        assertEquals("123 Some St", c.getAddress());
    }

    @Test
    void testInvalidContactID_Null() {
        assertThrows(IllegalArgumentException.class, () -> {
            new Contact(null, "John", "Doe", "1234567890", "123 Some St");
        });
    }

    @Test
    void testInvalidContactID_TooLong() {
        assertThrows(IllegalArgumentException.class, () -> {
            new Contact("123456789012", "John", "Doe", "1234567890", "123 Some St");
        });
    }

    @Test
    void testInvalidFirstName_Null() {
        assertThrows(IllegalArgumentException.class, () -> {
            new Contact("123", null, "Doe", "1234567890", "123 Some St");
        });
    }

    @Test
    void testInvalidFirstName_TooLong() {
        assertThrows(IllegalArgumentException.class, () -> {
            new Contact("123", "ThisIsWayTooLong", "Doe", "1234567890", "123 Some St");
        });
    }

    @Test
    void testInvalidPhoneNumber_NotTenDigits() {
        assertThrows(IllegalArgumentException.class, () -> {
            new Contact("123", "John", "Doe", "12345", "123 Some St");
        });
    }

    @Test
    void testInvalidAddress_Null() {
        assertThrows(IllegalArgumentException.class, () -> {
            new Contact("123", "John", "Doe", "1234567890", null);
        });
    }

    @Test
    void testInvalidAddress_TooLong() {
        // 31 characters — breaks the 30 char rule
        String longAddress = "1234567890123456789012345678901";
        assertThrows(IllegalArgumentException.class, () -> {
            new Contact("123", "John", "Doe", "1234567890", longAddress);
        });
    }

    @Test
    void testSetPhoneNumber() {
        Contact c = new Contact("123", "Jane", "Doe", "1234567890", "456 Another St");
        c.setPhoneNumber("0987654321");
        assertEquals("0987654321", c.getPhoneNumber());

        // Try a bad one now
        assertThrows(IllegalArgumentException.class, () -> {
            c.setPhoneNumber("1234");
        });
    }
}

