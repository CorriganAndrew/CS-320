package com.contact;

import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

/**
 * Tests the ContactService class to make sure:
 *  - addContact keeps IDs unique
 *  - deleteContact works as expected
 *  - updateContact changes the right fields
 *  - getContact gives the right result
 */
public class ContactServiceTest {

    private ContactService service;

    @BeforeEach
    void setUp() {
        // Reset the service before each test
        service = new ContactService();
    }

    @Test
    void testAddContact() {
        Contact c = new Contact("111", "Alice", "Smith", "1234567890", "Some Address");
        service.addContact(c);
        Contact retrieved = service.getContact("111");
        assertNotNull(retrieved);
        assertEquals("Alice", retrieved.getFirstName());
    }

    @Test
    void testAddDuplicateID() {
        Contact c1 = new Contact("111", "Alice", "Smith", "1234567890", "Some Address");
        Contact c2 = new Contact("111", "Bob", "Jones", "0987654321", "Another Address");

        service.addContact(c1);
        // Should fail because same ID already exists
        assertThrows(IllegalArgumentException.class, () -> service.addContact(c2));
    }

    @Test
    void testDeleteContact() {
        Contact c = new Contact("222", "Charlie", "Brown", "1234567890", "Some Address");
        service.addContact(c);
        assertNotNull(service.getContact("222"));

        service.deleteContact("222");
        assertNull(service.getContact("222"));
    }

    @Test
    void testUpdateContact() {
        Contact c = new Contact("333", "Diana", "Prince", "1234567890", "Old Address");
        service.addContact(c);

        service.updateContact("333", "Diane", "Princely", "0987654321", "New Address");

        Contact updated = service.getContact("333");
        assertEquals("Diane", updated.getFirstName());
        assertEquals("Princely", updated.getLastName());
        assertEquals("0987654321", updated.getPhoneNumber());
        assertEquals("New Address", updated.getAddress());
    }

    @Test
    void testUpdateNonExistentContact() {
        // Should fail because contact doesn't exist
        assertThrows(IllegalArgumentException.class, () -> {
            service.updateContact("999", "No", "Body", "0000000000", "Nowhere");
        });
    }
}
