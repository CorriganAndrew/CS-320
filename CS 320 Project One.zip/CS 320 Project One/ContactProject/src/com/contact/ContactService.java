package com.contact;

import java.util.HashMap;
import java.util.Map;

/**
 * Manages a bunch of Contact objects.
 * You can:
 *  - Add a new contact (must have a unique ID)
 *  - Delete a contact by ID
 *  - Update contact details
 *  - Look one up by ID
 */
public class ContactService {

    // HashMap = easy way to store/retrieve contacts by their ID
    private Map<String, Contact> contacts = new HashMap<>();

    /**
     * Adds a new contact if the ID doesn't already exist.
     */
    public void addContact(Contact contact) {
        if (contacts.containsKey(contact.getContactID())) {
            throw new IllegalArgumentException("Contact ID already exists: " + contact.getContactID());
        }
        contacts.put(contact.getContactID(), contact);
    }

    /**
     * Removes a contact by ID.
     * (Does nothing if the contact isn’t there — could throw instead if you wanted.)
     */
    public void deleteContact(String contactID) {
        contacts.remove(contactID);
    }

    /**
     * Updates all the editable fields of a contact — ID stays locked in.
     */
    public void updateContact(String contactID,
                              String newFirstName,
                              String newLastName,
                              String newPhoneNumber,
                              String newAddress) {
        Contact existingContact = contacts.get(contactID);

        if (existingContact == null) {
            throw new IllegalArgumentException("Contact not found: " + contactID);
        }

        // Setters already validate the input, so just call them
        existingContact.setFirstName(newFirstName);
        existingContact.setLastName(newLastName);
        existingContact.setPhoneNumber(newPhoneNumber);
        existingContact.setAddress(newAddress);
    }

    /**
     * Finds a contact by ID, or gives you null if they’re not in the list.
     */
    public Contact getContact(String contactID) {
        return contacts.get(contactID);
    }
}

