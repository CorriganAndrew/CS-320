package com.contact;

/**
 * Represents a contact with some built-in rules:
 *  - contactID: final (can’t be changed), max 10 characters, not null
 *  - firstName & lastName: max 10 characters, not null
 *  - phoneNumber: must be exactly 10 digits
 *  - address: max 30 characters
 */
public class Contact {
    private final String contactID;
    private String firstName;
    private String lastName;
    private String phoneNumber;
    private String address;

    // When you create a Contact, this constructor checks that all your info is valid
    public Contact(String contactID,
                   String firstName,
                   String lastName,
                   String phoneNumber,
                   String address) {
        
        // ID checks — can’t be null or longer than 10 characters
        if (contactID == null || contactID.length() > 10) {
            throw new IllegalArgumentException("Invalid contact ID (null or exceeds 10 chars)");
        }
        this.contactID = contactID;

        // Use setters to reuse validation logic
        setFirstName(firstName);
        setLastName(lastName);
        setPhoneNumber(phoneNumber);
        setAddress(address);
    }

    // --- GETTERS ---
    public String getContactID() {
        return contactID;
    }

    public String getFirstName() {
        return firstName;
    }

    public String getLastName() {
        return lastName;
    }

    public String getPhoneNumber() {
        return phoneNumber;
    }

    public String getAddress() {
        return address;
    }

    // --- SETTERS ---
    // First and last name must be short (<= 10) and not null
    public void setFirstName(String firstName) {
        if (firstName == null || firstName.length() > 10) {
            throw new IllegalArgumentException("Invalid first name (null or exceeds 10 chars)");
        }
        this.firstName = firstName;
    }

    public void setLastName(String lastName) {
        if (lastName == null || lastName.length() > 10) {
            throw new IllegalArgumentException("Invalid last name (null or exceeds 10 chars)");
        }
        this.lastName = lastName;
    }

    // Phone number has to be exactly 10 digits
    public void setPhoneNumber(String phoneNumber) {
        if (phoneNumber == null || phoneNumber.length() != 10) {
            throw new IllegalArgumentException("Invalid phone number (null or not exactly 10 digits)");
        }
        this.phoneNumber = phoneNumber;
    }

    // Address can’t be too long or null
    public void setAddress(String address) {
        if (address == null || address.length() > 30) {
            throw new IllegalArgumentException("Invalid address (null or exceeds 30 chars)");
        }
        this.address = address;
    }
}
